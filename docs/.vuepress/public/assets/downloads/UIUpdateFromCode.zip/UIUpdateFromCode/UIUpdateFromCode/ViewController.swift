//
//  ViewController.swift
//  UIUpdateFromCode
//
//  Created by seb on 2020-11-17.
//  Copyright © 2020 seb. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    // Declare some UI objects we want to create
    @IBOutlet var newTextView: UITextView!
    @IBOutlet var newTextField: UITextField!
    @IBOutlet var newImageView: UIImageView!
    @IBOutlet var newImageViewSmall: UIImageView!
    @IBOutlet var newButton: UIButton!
    
    // Make a Rect to hold the main super-view's frame
    var viewFrame : CGRect!
    
    // Make a bool used to represent an on/off toggle option for use in the button action
    var toggleHeight = false
    
    // Make a CGFloat to hold a value to modify the height and vertical position of UI objects
    var heightModifier : CGFloat = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        // Create a TextView, TextField, Image, and Button
        createTextView()
        createTextField()
        createImageView()
        createButton()
    }
    
    override func viewWillLayoutSubviews() {
    }
    
    // Hide the keyboard when the main view is clicked
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    
    
    // Write code that will modify the UI layout using an animation when the view appears
    override func viewWillAppear(_ animated: Bool) {
        // Get a copy of the main super-view's frame
        viewFrame = self.view.frame
        
        // Add the action to the button when touchUpInside is occures
        newButton.addTarget(self, action: #selector(myButtonAction), for: .touchUpInside)
        
        // Set some text in the textView and textField
        newTextView.text = "Hello world"
        newTextField.text = "Hi"
        newButton.setTitle("Send", for: .normal)
        
        // Modify the edit and select permission of the textView
        newTextView.isEditable = false
        newTextView.isSelectable = false
        
        // Call the view's animate() function to move around some of the UI when the view first appears
        UIView.animate(withDuration: 1.5, animations:  {
            // Animate the textField moving to a new location
            self.newTextField.frame.origin = CGPoint(x: self.viewFrame.minX+20, y: 350)
            
            // Animate the textView moving to a new location, and to a different size
            self.newTextView.frame.origin = CGPoint(x: self.viewFrame.minX+20, y: self.viewFrame.minY+35)
            self.newTextView.frame.size = CGSize(width: self.viewFrame.maxX-40, height: self.viewFrame.maxY / 2 - 70)
            
            // Animate the imageView moving to a new location, with a new size at the same time
            self.newImageView.frame = CGRect(x: self.viewFrame.maxX/2-55, y: self.viewFrame.maxY/1.65, width: 110, height: 110)
        })
    }
    
    
    // ACTION: myButtonAction()
    // - A method called when the button is touched
    @IBAction func myButtonAction(_ sender: Any) {
        // Call the overloaded UIView.animate() function that uses a completion handler after the animations finishes
        UIView.animate(withDuration: 0.7,
                       animations: moveUIObjects,
                       completion: toggleTextField)
    }
    
    
    // A function that will toggle the position of UI objects based on the toggleHeight bool every time this is function is called
    func moveUIObjects () -> Void {
        // Toggle setting the hight modifier value that will be used for changing the UI's size and shape based on the toggle value
        heightModifier = 2.0
        
        if toggleHeight == false {
            heightModifier = 6.0
        }
        
        toggleHeight = !toggleHeight
        
        // Animate the textView moving to a new location, and to a different size
        self.newTextView.frame.size = CGSize(width: self.newTextView.frame.width, height: ((self.viewFrame.maxY / self.heightModifier) - 70) )
        
        // Animate the imageView moving to a new location, with a new size at the same time
        self.newImageView.frame = CGRect(x: self.viewFrame.maxX/2-55, y: self.viewFrame.maxY/1.65 + ((2.0 - self.heightModifier) * 40), width: 110, height: 110)
        
        // Change imageView alpha level
        self.newImageView.alpha = 1.0 / (heightModifier - 1.0)
        
        // Animate the textField moving to a new location
        self.newTextField.frame.origin = CGPoint(x: self.viewFrame.minX+20, y: 350 - ((heightModifier-2.0)*60.0) )
        
        // Change textField alpha level
        self.newTextField.alpha = 1.0 - ((heightModifier - 2.0)/4.0)
    }
    
    
    // A completion handler function that is fired when the animation has finished
    func toggleTextField (input : Bool) -> Void {
        // Toggle the hidden and disabled parameter the textField
        //self.newTextField.isHidden = !self.newTextField.isHidden
        self.newTextField.isEnabled = !self.newTextField.isEnabled
    }







    // Definition for the createTextView function
    func createTextView() {
        // Define the new TextView size and positioning with a rectlet
        let textViewFrame = CGRect(x: 20, y: 340, width: 340, height: 200)
        // Create TextViewobject
        newTextView = UITextView(frame: textViewFrame)
        // Add TextView to the main view
        self.view.addSubview(newTextView)
        
        // Setup TextView text, and style
        newTextView.text = "This is some text."
        newTextView.textColor = UIColor(red: 0.9, green: 0.9, blue: 0.9, alpha: 1.0)
        newTextView.backgroundColor = UIColor.darkGray
    }
    
    // Definition for the createTextField function
    func createTextField() {
        // Define the new TextView size and positioning with a rectlet
        let textFieldFrame = CGRect(x: 25, y: 280, width: 330, height: 40)
        // Create TextViewobject
        newTextField = UITextField(frame: textFieldFrame)
        // Add TextView to the main view
        self.view.addSubview(newTextField)
        
        // Setup TextField placeholder-text, and style
        newTextField.placeholder = "This is placeholder text."

        // Setup TextField font
        newTextField.font =  UIFont.systemFont(ofSize: 14) //UIFont(name: "", size: 14)

        // Setup TextField text and background colors
        newTextField.backgroundColor = UIColor(red: 0.5, green: 0.8, blue: 0.5, alpha: 1.0)
        newTextField.textColor = UIColor.black

        // Setup TextField border style
        newTextField.layer.cornerRadius = 18
        newTextField.layer.borderWidth = 3
        newTextField.layer.borderColor = UIColor.lightGray.cgColor

        // Setup TextField padding
        newTextField.layer.sublayerTransform = CATransform3DMakeTranslation(10, 0, 0)

        // Setup TextField's security mode (normal or password)
        newTextField.isSecureTextEntry = false
    }
    
    // Definition for the createImage function
    func createImageView() {
        
        // Create imageView object (size is automatically calculated from the image)
        newImageView = UIImageView(image: UIImage(named: "ACLogo"))
        
        // Define the new imageView positioning with a point
        let imagePosition = CGPoint(x: 35, y: 35)
        // Set the image's position
        newImageView.frame.origin = imagePosition
        
        // Add imageView to the main view
        self.view.addSubview(newImageView)
        
        
        // ALTERNATIVE METHOD: Make an image with a customized size
        
        // Define the new imageView size and positioning with a rect
        let imageFrame = CGRect(x: 65, y: 595, width: 30, height: 22)
    
        // Set a new size if the original size is not desired
        //newImageView.frame = imageFrame
        newImageViewSmall = UIImageView(frame: imageFrame)
        
        // Add imageView to the main view
        self.view.addSubview(newImageViewSmall)
        
        // Create imageView object (size is automatically calculated from the image)
        newImageViewSmall.image = UIImage(named: "ACLogo")
    }
    
    // Definition for the createButton function
    func createButton() {
        // Define the new Button size and positioning with a rect
        let buttonFrame = CGRect(x: 160, y: 580, width: 200, height: 50)
        
        // Create Button object
        newButton = UIButton(frame: buttonFrame)
        
        // Add TextView to the main view
        self.view.addSubview(newButton)
        
        // Setup Button text and style
        newButton.setTitle("Press Me", for: .normal)
        newButton.setTitleColor(UIColor.cyan, for: .highlighted)
        newButton.backgroundColor = UIColor.gray
    }
}

