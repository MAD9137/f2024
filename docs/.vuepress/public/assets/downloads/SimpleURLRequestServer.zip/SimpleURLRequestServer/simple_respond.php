<?php

	$response = "ERROR - No name value";
	
	if( isset($_GET['name']) ) 
	{
		$response = 'Hello ' . $_GET['name'];
		
	    if( $_GET['name'] == 'Jon' ) 
	    {
	        $response .= " Dow";
	    }
	    
	}

	echo $response;

?>