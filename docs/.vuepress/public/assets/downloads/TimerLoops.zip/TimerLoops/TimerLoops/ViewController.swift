//
//  ViewController.swift
//  TimerLoops
//
//  Created by seb on 2020-11-26.
//  Copyright © 2020 seb. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var timerProgress: UIProgressView!
    @IBOutlet weak var timerLabel: UILabel!
    
    @IBOutlet weak var cadlProgress: UIProgressView!
    @IBOutlet weak var cadlLabel: UILabel!
    
    var timer : Timer?
    var cadlTimer : CADisplayLink?
    
    var timerCount : Float = 0.0
    var cadlCount : Float = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        timerProgress.progress = 0.0
        cadlProgress.progress = 0.0
    }
    
    @IBAction func timerButton(_ sender: Any) {
        // If the timer has not been started, then create it
        if timer == nil {
            
            // Create a timer object, set the length of interval between calls to the selector function, and set the timer to loop
            timer = Timer.scheduledTimer(timeInterval: 0.005, target: self, selector: #selector(timerCallBack), userInfo: nil, repeats: true)
            
            // Tell the timer to start
            timer!.fire()
        }
    }
    
    @objc func timerCallBack () {
        timerCount = timerCount + 0.0025
        
        if timerCount > 1.0 {
            timerCount = 1.0
        }
        
        self.timerLabel.text = "Updated \(timerCount)"
        self.timerProgress.progress = timerCount
        
        if timerCount == 1.0 {
            timer?.invalidate()
            timer = nil
            timerCount = 0.0
        }
    }
    
    @IBAction func cadlButton(_ sender: Any) {
        // If the timer has not been started, then create it
        if cadlTimer == nil {
            // Create a timer object that will call our function cadlTimerCallBack
            cadlTimer = CADisplayLink(target: self, selector: #selector(cadlTimerCallBack))
            
            // Set how often this timer should run the callback function
            cadlTimer?.preferredFramesPerSecond = 60
            
            // Add this timer to the current time loop to start it running
            cadlTimer?.add(to: .current, forMode: RunLoop.Mode.default)
        }
    }
    
    @objc func cadlTimerCallBack () {
        cadlCount = cadlCount + 0.008333
        
        if cadlCount > 1.0 {
            cadlCount = 1.0
        }
        
        self.cadlLabel.text = "Updated \(cadlCount)"
        self.cadlProgress.progress = cadlCount
        
        if cadlCount == 1.0 {
            cadlTimer?.invalidate()
            cadlTimer = nil
            cadlCount = 0.0
        }
    }
    
}

