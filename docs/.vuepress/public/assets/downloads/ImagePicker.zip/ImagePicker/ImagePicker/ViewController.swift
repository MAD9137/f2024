//
//  ViewController.swift
//  ImagePicker
//
//  Created by Seb L on 2017-10-27.
//  Copyright © 2017 Seb L. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate {

    @IBOutlet weak var myImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    @IBAction func chooseImageButton(_ sender: Any) {
        let picker: UIImagePickerController = UIImagePickerController()
        picker.sourceType = UIImagePickerControllerSourceType.photoLibrary
        picker.delegate = self
        picker.allowsEditing = false
        present(picker, animated: true, completion: nil)
    }
    
    
    @IBAction func takePhotoButton(_ sender: Any) {
        let camera: UIImagePickerController = UIImagePickerController()
        camera.sourceType = UIImagePickerControllerSourceType.camera
        camera.delegate = self
        camera.allowsEditing = false
        present(camera, animated: true, completion: nil)
    }
    
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let img = info[UIImagePickerControllerOriginalImage] as? UIImage {
            myImageView.image = img
        }
        
        picker.dismiss(animated: true, completion: nil)
    }
    
}

