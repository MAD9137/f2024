//
//  ViewController.swift
//  URLRequestSendPost
//
//  Created by seb on 2020-12-10.
//  Copyright © 2020 seb. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var outputTextView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    
    @IBAction func sendButtonAction(_ sender: Any) {
        
        view.endEditing(true)
        
        // Check if textFields have text entered
        if let nameText = nameField.text, let emailText = emailField.text {
            if !nameText.isEmpty && !emailText.isEmpty {
                
                // Define the url that you want to send a request to.
                let requestUrl: URL = URL(string: "http://localhost:8888/mad9137/postData/receivePost.php")!
                
                // Create the request object and pass in your url
                var myRequest: URLRequest = URLRequest(url: requestUrl)
                
                // ---- Add the POST request code here.
                    // Set the http method to POST (instead of the default of GET)
                    myRequest.httpMethod = "POST"
                    
                    // Create a string to hold the converted json data
                    var jsonString : String?
                    
                    // Create a dictionary to hold the swift variables for the json data
                    let jsonDictionary: [String:String] = [
                        "name" : nameText,
                        "email" : emailText
                    ]
                    
                    // Try to convert the dictionary to data, set the jsonString variable to a string converted from the data
                    do {
                        let jsonData : Data? = try JSONSerialization.data(withJSONObject: jsonDictionary, options: [])
                        jsonString = String(data: jsonData!, encoding: .utf8)
                    }
                    catch {
                        print ("Coverted error = \(error.localizedDescription)")
                    }
                    
                    // If the string has been created then add the POST key = the string of json text.
                    if let string = jsonString {
                        let postString = "myPostInfo=\(string)"
                        // Convert the string with the POST key/value info into data and set it as the httpBody of the request.
                        myRequest.httpBody = postString.data(using: .utf8)
                    }
                // ---- Finished proccessing the post request here.
                
                // Create the URLSession object that will make the request.
                let mySession: URLSession = URLSession.shared
                
                // Make the specific task from the session by passing in your request, and the function that will be use to handle the request.
                let myTask = mySession.dataTask(with: myRequest, completionHandler: requestTask)
                
                // Tell the task to run.
                myTask.resume()
                
                
                
                
            }
        }
        
    }
    
    
    // Define a function that will handle the request which will need to recieve the data send back, the respinse status, and an error object to handle any errors returned
    func requestTask (serverData: Data?, serverResponse: URLResponse?, serverError: Error?) -> Void{
        // If the error object has been set then an error occured
        if serverError != nil {
            // Send en empty string as the data, and the error to the callback function.
            self.myCallback(responseString: "", error: serverError?.localizedDescription)
        }else{
            // If there was no errors, stringify the response data.
            let result = String(data: serverData!, encoding: .utf8)!
            // Send the response string data, and nil for the error to the callback.
            self.myCallback(responseString: result as String, error: nil)
        }
    }
    
    
    // Define the callback function to be triggered when the response is recieved.
    func myCallback(responseString: String, error: String?) {

        // If the server request generated an error then handle it.
        if error != nil {
            print("ERROR is " + error!)
        }else{
            // Else take the data recieved from the server and process it.
            print("DATA: " + responseString)
            
            // Update UI with responseString on the main thread by calling the DispatchQueue.main.async() method.
            DispatchQueue.main.async() {
                self.outputTextView.text = "Server response>\n" + responseString
            }
            
        }
        
        
    }
    
    
    
    
    
    
    
    
}

