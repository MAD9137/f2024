//
//  ViewController.swift
//  SimpleURLRequest
//
//  Created by Seb L on 2018-11-11.
//  Copyright © 2018 Seb L. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func loadButton(_ sender: Any) {
        
        // Define the url that you want to send a request to.
        let requestUrl: URL = URL(string: "http://lenczes.edumedia.ca/mad9137/simpleRequest/simple_respond.php?name=Jon")!
        
        // Create the request object and pass in your url
        let myRequest: URLRequest = URLRequest(url: requestUrl)
        
        // Create the URLSession object that will make the request
        let mySession: URLSession = URLSession.shared
        
        // Make the specific task from the session by passing in your request, and the function that will be use to handle the request
        let myTask = mySession.dataTask(with: myRequest, completionHandler: requestTask)
        
        // Tell the task to run
        myTask.resume()
    }
    
    // Define a function that will handle the request which will need to recieve the data send back, the respinse status, and an error object to handle any errors returned
    func requestTask (serverData: Data?, serverResponse: URLResponse?, serverError: Error?) -> Void{
        
        // If the error object has been set then an error occured
        if serverError != nil {
            // Send en empty string as the data, and the error to the callback function
            self.myCallback(responseString: "", error: serverError?.localizedDescription)
        }else{
            // If no error was generated then the server responce has been recieved
            // Stringify the response data
            let result = String(data: serverData!, encoding: .utf8)!
            // Send the response string data, and nil for the error tot he callback
            self.myCallback(responseString: result as String, error: nil)
        }
    }
    
    // Define the callback function to be triggered when the response is recieved
    func myCallback(responseString: String, error: String?) {
        
        // Define a String used for outputting the response text to the label
        var outputText: String?
        
        // If the server request generated an error then handle it
        if error != nil {
            print("ERROR is " + error!)
        }else{
            // Else take the data recieved from the server and process it
            print("DATA is " + responseString)
            outputText = responseString
        }
        
        // This callback is run on a secondary thread, so you must make any UI changes on the main thread by calling the DispatchQueue.main.async() method
        DispatchQueue.main.async() {
            // Update the textLabel with the server resonse
            self.myLabel.text = "Server> " + outputText!
        }
    }
    
}
