<?php
	///receivePost.php
	
	// required headers
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	
    if (isset($_POST["myPostInfo"])) {
        
        $jsonObj = json_decode($_POST["myPostInfo"], true);
        
        $name = $jsonObj["name"];
        $email = $jsonObj["email"];
        
        echo "JSON string received = " . $_POST["myPostInfo"] . "\nName: " . $name . "\nEmail: " . $email;
        
    }
    else {
        echo json_encode( array("server_message" => "ERROR: Missing correct json POST data.") );
    }
    
?>
