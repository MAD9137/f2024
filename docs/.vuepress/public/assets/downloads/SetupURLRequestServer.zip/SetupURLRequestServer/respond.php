<?php
	
    date_default_timezone_set('America/Montreal');
    
	echo "Server response text " . date('Y-m-d H:i:s');
	
?>
