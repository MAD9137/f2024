<?php
	
	echo "Server response text " . date('Y-m-d H:i:s');
	
?>