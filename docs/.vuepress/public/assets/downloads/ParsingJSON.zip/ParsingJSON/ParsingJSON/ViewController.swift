//
//  ViewController.swift
//  ParsingJSON
//
//  Created by Seb L on 2018-11-11.
//  Copyright © 2018 Seb L. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    // Create UI outlet
    @IBOutlet weak var myTextView: UITextView!
    
    // An example of a string containing JSON data
    let myJSONString = "{\"students\":[{\"studentID\":0, \"studentName\":\"Jane Doe\",\"studentAge\":25, \"studentGrade\":97.5}, {\"studentID\":1, \"studentName\":\"Bob Lee\", \"studentAge\":19, \"studentGrade\":78.6}, {\"studentID\":2, \"studentName\":\"Tammy Tam\", \"studentAge\":22, \"studentGrade\":94.2},{\"studentID\":3, \"studentName\":\"Jason Jasonson\", \"studentAge\":31, \"studentGrade\":89.1}]}"
    
    // Define an optionl object to store the JSON response data.  In this case the JSON data has a key called 'students' with a value that is equal to an array of dictionaries
    var jsonObject: [String:[[String:Any]]]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Print out the raw JSON to help validate it's structure
        print (myJSONString)
        
        // Call function to pars JSON into optional dictionary jsonOobject
        parseMyJSON()
        
        // Call function to itterate through optional dictionary jsonObject and output values
        outputJSONValues()
    }
    
    
    // Function used to pars JSON data into jsonObject
    func parseMyJSON() {
        
        // If the JSON information is a string, it must first be converted into an object of type Data
        if let myData: Data = myJSONString.data(using: String.Encoding.utf8) {
            do {
                // Try to convert JSON data into a JSON dictionary to be saved into the optional dictionary
                jsonObject = try JSONSerialization.jsonObject(with: myData, options: []) as? [String:[[String:Any]]]
                
            } catch let convertError {
                // If converting the string back into data fails catch the error info
                print("ERROR: " + convertError.localizedDescription)
            }
        }
    }
    
    
    // Function that will itterate through optional dictionary jsonObject and output values
    func outputJSONValues() {
        
        // Make output string
        var outputString = ""
        
        // Use optional binding to safely access jsonObject
        if let jsonObj = jsonObject{
            // Use optional binding to safely access the array of dictionaries in the jsonObject
            if let jsonArray = jsonObj["students"] as [[String:Any]]? {
                // Itterate through the array od dictionaries
                for thisDictionary in jsonArray {
                    // Get the current array element which is a dictionary containing a single students records
                    let jsonDictionaryRow = thisDictionary as [String:Any]
                    
                    // Get the id,name, age and grade for the current student and cast the value from Any to the apropriate type
                    let id    = jsonDictionaryRow["studentID"] as? Int
                    let name  = jsonDictionaryRow["studentName"] as? String
                    let age   = jsonDictionaryRow["studentAge"] as? Int
                    let grade = jsonDictionaryRow["studentGrade"] as? Double
                    
                    // Bind the 4 optional values above to make sure they all have a value, and none of them are nil
                    if let id = id, let name = name, let age = age, let grade = grade {
                        // Append the current students information to the outputString
                        outputString += "\(id) - \(name) (age: \(age), grade: \(grade) )\n\n"
                    }
                }
                // Output the students information to the textView
                self.myTextView.text = outputString
            }
        }
    }


}

