//
//  ViewController.swift
//  UIFromCode
//
//  Created by seb on 2020-11-17.
//  Copyright © 2020 seb. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    // Declare some UI objects we want to create
    @IBOutlet var newTextView: UITextView!
    @IBOutlet var newTextField: UITextField!
    @IBOutlet var newImageView: UIImageView!
    @IBOutlet var newImageViewSmall: UIImageView!
    @IBOutlet var newButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        // Create a TextView, TextField, Image, and Button
        createTextView()
        createTextField()
        createImageView()
        createButton()
    }
    
    override func viewWillLayoutSubviews() {
    }
    
    // Definition for the createTextView function
    func createTextView() {
        // Define the new TextView size and positioning with a rectlet
        let textViewFrame = CGRect(x: 20, y: 340, width: 340, height: 200)
        // Create TextViewobject
        newTextView = UITextView(frame: textViewFrame)
        // Add TextView to the main view
        self.view.addSubview(newTextView)
        
        // Setup TextView text, and style
        newTextView.text = "This is some text."
        newTextView.textColor = UIColor(red: 0.9, green: 0.9, blue: 0.9, alpha: 1.0)
        newTextView.backgroundColor = UIColor.darkGray
    }
    
    // Definition for the createTextField function
    func createTextField() {
        // Define the new TextView size and positioning with a rectlet
        let textFieldFrame = CGRect(x: 25, y: 280, width: 330, height: 40)
        // Create TextViewobject
        newTextField = UITextField(frame: textFieldFrame)
        // Add TextView to the main view
        self.view.addSubview(newTextField)
        
        // Setup TextField placeholder-text, and style
        newTextField.placeholder = "This is placeholder text."

        // Setup TextField font
        newTextField.font =  UIFont.systemFont(ofSize: 14) //UIFont(name: "", size: 14)

        // Setup TextField text and background colors
        newTextField.backgroundColor = UIColor(red: 0.5, green: 0.8, blue: 0.5, alpha: 1.0)
        newTextField.textColor = UIColor.black

        // Setup TextField border style
        newTextField.layer.cornerRadius = 18
        newTextField.layer.borderWidth = 3
        newTextField.layer.borderColor = UIColor.lightGray.cgColor

        // Setup TextField padding
        newTextField.layer.sublayerTransform = CATransform3DMakeTranslation(10, 0, 0)

        // Setup TextField's security mode (normal or password)
        newTextField.isSecureTextEntry = false
    }
    
    // Definition for the createImage function
    func createImageView() {
        
        // Create imageView object (size is automatically calculated from the image)
        newImageView = UIImageView(image: UIImage(named: "ACLogo"))
        
        // Define the new imageView positioning with a point
        let imagePosition = CGPoint(x: 35, y: 35)
        // Set the image's position
        newImageView.frame.origin = imagePosition
        
        // Add imageView to the main view
        self.view.addSubview(newImageView)
        
        
        // ALTERNATIVE METHOD: Make an image with a customized size
        
        // Define the new imageView size and positioning with a rect
        let imageFrame = CGRect(x: 65, y: 595, width: 30, height: 22)
    
        // Set a new size if the original size is not desired
        //newImageView.frame = imageFrame
        newImageViewSmall = UIImageView(frame: imageFrame)
        
        // Add imageView to the main view
        self.view.addSubview(newImageViewSmall)
        
        // Create imageView object (size is automatically calculated from the image)
        newImageViewSmall.image = UIImage(named: "ACLogo")
    }
    
    // Definition for the createButton function
    func createButton() {
        // Define the new Button size and positioning with a rect
        let buttonFrame = CGRect(x: 160, y: 580, width: 200, height: 50)
        
        // Create Button object
        newButton = UIButton(frame: buttonFrame)
        
        // Add TextView to the main view
        self.view.addSubview(newButton)
        
        // Setup Button text and style
        newButton.setTitle("Press Me", for: .normal)
        newButton.setTitleColor(UIColor.cyan, for: .highlighted)
        newButton.backgroundColor = UIColor.gray
    }
}

