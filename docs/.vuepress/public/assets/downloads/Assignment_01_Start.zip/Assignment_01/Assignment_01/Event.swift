//
//  Event.swift
//  Assignment_01
//
//  Created by seb on 2020-09-21.
//  Copyright © 2020 seb. All rights reserved.
//

import Foundation
