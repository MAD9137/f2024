//
//  ViewController.swift
//  UserDefaults
//
//  Created by seb on 2020-12-07.
//  Copyright © 2020 seb. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myLabel: UILabel!
    @IBOutlet weak var mySlider: UISlider!
    @IBOutlet weak var clearButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

        let userDefaults: UserDefaults = UserDefaults.standard
        
        let userSliderValue: Float? = userDefaults.value(forKey: "mySliderValue") as? Float
        
        if let myFloat = userSliderValue {
            mySlider.value = myFloat
        }else{
            mySlider.value = 0
            clearButton.isEnabled = false
        }
        
        myLabel.text = "Value: \(mySlider.value)"
    }

    @IBAction func clearButtonAction(_ sender: Any) {
        let appDomain: String = Bundle.main.bundleIdentifier!
        UserDefaults.standard.removePersistentDomain(forName: appDomain)
        mySlider.value = 0.0
        myLabel.text = "Value: \(mySlider.value)"
        clearButton.isEnabled = false
    }
    
    @IBAction func saveButtonAction(_ sender: Any) {
        let userDefaults: UserDefaults = UserDefaults.standard
        userDefaults.set(mySlider.value, forKey: "mySliderValue")
        myLabel.text = "Value: \(mySlider.value)"
        clearButton.isEnabled = true
    }
    


}

