//
//  ViewController.swift
//  BasicTimer
//
//  Created by seb on 2020-11-26.
//  Copyright © 2020 seb. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var outputLabel: UILabel!
    
    // Create an int to hold the number of seconds to delay code by
    let timeLimit = 3.0
    // Create Timer variable
    var timer : Timer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func startMainQueue(_ sender: Any) {
        print("MainQueue - code has been dispatched.")
        outputLabel.text = "MainQueue - code has been dispatched."
        // Execute some code on the main thread after the given deadline is reached
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + timeLimit) {
            // Code for delayed execution
            print("MainQueue - code executed after deadline reached.")
            self.outputLabel.text = "MainQueue - code executed after deadline reached."
        }
    }
    
    @IBAction func startDelayButton(_ sender: Any) {
        print("Perform - selector function will run after delay.")
        outputLabel.text = "Perform - selector function will run after delay."
        // Execute the selector function after the time delay has passed
        perform(#selector(delayButtonCallback), with: nil, afterDelay: timeLimit)
    }
    
    // Petform Selector function will run after delay
    @objc func delayButtonCallback () {
        print("Perform - selector function triggered after delay expired.")
        outputLabel.text = "Perform - selector function triggered after delay expired."
    }
    
    @IBAction func startTimerButton(_ sender: Any) {
        if timer == nil {
            print("Timer - selector function will run at scheduled date.")
            outputLabel.text = "Timer - selector function will run at scheduled date."
                
            // Initialize timer object to fire the timerCallBack function at a date in the future
            timer = Timer(fireAt: Date(timeIntervalSinceNow: timeLimit), interval: 0, target: self, selector: #selector(timerCallBack), userInfo: nil, repeats: false)
            
            // Add the timer to the current run-loop, and set it to run in the default run mode
            RunLoop.current.add(timer!, forMode: RunLoop.Mode.default)
            
        }
    }
    
    // Timer selector function to run at the scheduled date
    @objc func timerCallBack (t:Timer)  -> Void{
        print("Timer - selector callback run at scheduled date.")
        outputLabel.text = "Timer - selector callback run at scheduled date."
            
        // Stop and delete the Timer object
        timer!.invalidate()
        timer = nil
    }
    
}

