//
//  ViewController.swift
//  SwiftToJSON
//
//  Created by seb on 2020-11-20.
//  Copyright © 2020 seb. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    // Define outlets for the UI objects in the view
    @IBOutlet weak var myTextField: UITextField!
    @IBOutlet weak var myTextView: UITextView!
    @IBOutlet weak var mySlider: UISlider!
    @IBOutlet weak var myDatePicker: UIDatePicker!
    
    // Define a dictionary to hold the UI objects data
    var eventDictionary: [String: Any] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func convertButtonAction(_ sender: Any) {
        
        // Add the UI object's values for the appropriate keys in the dictionary
        eventDictionary["title"] = myTextField.text
        eventDictionary["description"] = myTextView.text
        eventDictionary["duration"] = mySlider.value
        //eventDictionary["date"] = myDatePicker.date.description
        eventDictionary["date"] = String(myDatePicker.date.description.dropLast(9))
        
        // Try to convert the dictionary to JSON data, and the data to a utf8 encoded string
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: eventDictionary, options: [])
            let jsonString = String(data: jsonData, encoding: .utf8)
            let escapedJSONString = jsonString?.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
            
            print (jsonString!,  "\n")
            print (escapedJSONString!)
        }
        catch {
            print ("Converted error = \(error.localizedDescription)")
        }
        
        
        
    }
    
}

