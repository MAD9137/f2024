//
//  ViewController.swift
//  URLRequestParsingJSON
//
//  Created by seb on 2020-11-23.
//  Copyright © 2020 seb. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    @IBAction func loadButton(_ sender: Any) {
        // Define the url that you want to send a request to.
        if let requestUrl: URL = URL(string: "https://lenczes.edumedia.ca/mad9137/jsonRequest/json_respond.php") {
            // Create the request object and pass in your url
            let myRequest: URLRequest = URLRequest(url: requestUrl)
            // Create the URLSession object that will make the request
            let mySession: URLSession = URLSession.shared
            // Make the specific task from the session by passing in your request, and the function that will be use to handle the request
            let myTask = mySession.dataTask(with: myRequest, completionHandler: requestTask)
            // Tell the task to run
            myTask.resume()
        }
    }
    
    
    // Define a function that will handle the request which will need to recieve the data send back, the respinse status, and an error object to handle any errors returned
    func requestTask (serverData: Data?, serverResponse: URLResponse?, serverError: Error?) -> Void{
        
        // If the error object has been set then an error occured
        if let errorObject = serverError {
            // Send en empty string as the data, and the error to the callback function
            self.myCallback(responseString: "", error: errorObject.localizedDescription)
        }else{
            // If no error was generated then the server responce has been recieved, then stringify the response data
            if let data = serverData, let result = String(data: data, encoding: String.Encoding.utf8) {
                // Send the response string data, and nil for the error tot he callback
                self.myCallback(responseString: result as String, error: nil)
            }
            else {
                print("Server data object is nil, or fialed to convert to string.")
            }
        }
    }
    
    // Define the callback function to be triggered when the response is recieved
    func myCallback(responseString: String, error: String?) {
        
        // Define an optional dictionary that takes a string as the key and any object as the value
        var jsonDictionary: [String:Any]?
        
        // If the server request generated an error then handle it
        if let errorString = error {
            print("ERROR is " + errorString)
        }else{
            // Else take the data recieved from the server and process it
            
            // Take the response string and turn it back into raw data
            if let myData: Data = responseString.data(using: String.Encoding.utf8) {
                do {
                    // Try to convert response data into a dictionary to be save into the jsonDictionary optional dictionary variable
                    jsonDictionary = try JSONSerialization.jsonObject(with: myData, options: []) as? [String:Any]
                } catch let convertError {
                    // If it fails catch the error info
                    print(convertError.localizedDescription)
                }
            }
        }
        
        // This callback is run on a secondary thread, so you must make any UI updates on the main thread by calling the DispatchQueue.main.async() method
        if let jDictionary = jsonDictionary {
            DispatchQueue.main.async() {
                // Get the values for the keys defined in the server responce JSON data
                let uName = jDictionary["name"] as? String
                let uEmail = jDictionary["email"] as? String
                
                // Update the textLabel with the server resonse
                if let name = uName, let email = uEmail {
                    self.myLabel.text = name + " (" + email + ")"
                }
            }
        }
        else{
            print("jsonDictionary equals nil becasue converting JSON data has failed.")
        }
    }
    
}

