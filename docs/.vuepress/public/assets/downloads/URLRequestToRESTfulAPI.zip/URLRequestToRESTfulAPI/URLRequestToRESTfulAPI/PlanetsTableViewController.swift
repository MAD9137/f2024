//
//  PlanetsTableViewController.swift
//  URLRequestToRESTfulAPI
//
//  Created by seb on 2020-11-25.
//  Copyright © 2020 seb. All rights reserved.
//

import UIKit

class PlanetsTableViewController: UITableViewController {

    @IBOutlet weak var loadButton: UIBarButtonItem!
    
    // Define an optionl object to store the JSON response data.  In this case the planets JSON data has an array of dictionaries
    var jsonObjects: [String: [[String:Any]]]?
    var jsonArray: [[String:Any]]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Make url request
        requestPlanets()
    }
    
    // The load button action is used to get the JSON data forr all the plpanets
    @IBAction func loadButtonAction(_ sender: Any) {
        // Make url request
        requestPlanets()
    }
    
    // URLREQUEST TASK AND CALLBACK
    
    
    // A function that will request the json data for the planets
    func requestPlanets() {
        // Update navbar title to show loading status
        self.title = "Loading"
        
        // Define the url that you want to send a request to
        let requestUrl: URL = URL(string: "https://lenczes.edumedia.ca/mad9137/pa_api/planet/read_all.php")!
        // Create the request object and pass in your url
        let myRequest: URLRequest = URLRequest(url: requestUrl)
        // Create the URLSession object that will make the request
        let mySession: URLSession = URLSession.shared
        
        // Make the specific task from the session by passing in your request, and the function that will be use to handle the request
        let myTask = mySession.dataTask(with: myRequest, completionHandler: requestTask )
        // Tell the task to run
        myTask.resume()
    }
    
    
    // Define a function that will handle the request which will need to recieve the data send back, the respinse status, and an error object to handle any errors returned
    func requestTask (_ serverData: Data?, serverResponse: URLResponse?, serverError: Error?) -> Void{
        
        // If the error object has been set then an error occured
        if serverError != nil {
            // Send en empty string as the data, and the error to the callback function
            DispatchQueue.main.async {
                self.loadButton.isEnabled = true
            }
            self.myCallback("", error: serverError?.localizedDescription)
        }else{
            // If no error was generated then the server responce has been recieved
            // Stringify the response data
            let result = String(data: serverData!, encoding: String.Encoding(rawValue: String.Encoding.utf8.rawValue))!
            // Send the response string data, and nil for the error tot he callback
            DispatchQueue.main.async {
                self.loadButton.isEnabled = false
            }
            self.myCallback(result, error: nil)
        }
    }
    
    
    // Define the callback function to be triggered when the response is received
    func myCallback(_ responseString: String, error: String?) {
        
        // If the server request generated an error then handle it
        if error != nil {
            print("DATA LIST LOADING ERROR: " + error!)
            //TODO Add alert pop-up showing error info
        }else{
            // Else take the data recieved from the server and process it
            print("DATA RECEIVED: " + responseString)
            
            // Take the response string and turn it back into raw data
            if let myData: Data = responseString.data(using: String.Encoding.utf8) {
                do {
                    // Try to convert response data into a JSON dictionary to be saved into the optional dictionary
                    jsonObjects = try JSONSerialization.jsonObject(with: myData, options: []) as? [String: [[String:Any]]]
                    jsonArray = jsonObjects!["planets"]
                    
                } catch let convertError {
                    // If converting the string back into data fails catch the error info
                    print(convertError.localizedDescription)
                }
                
            }
            
            // UI updates need to be made on the main thread
            DispatchQueue.main.async {
                // Update the tableView with the data in the JSON dictionary
                self.tableView!.reloadData()
                // Update navbar title to show loading is done
                self.title = "Planet List"
            }
        }
    }
    
    
    // TABLE VIEW SETUP
    
    
    // Set row hight
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 74.0
    }
    
    
    // Create a table cell for each item in the array if it is not nil, otherwise return 0
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        var cellCount = 0
        
        // Use optional binding to return the count of the jsonObjects array
        if let jsonObj = jsonArray {
            cellCount = jsonObj.count
        }
        
        return cellCount
    }
    
    
    // For each dictionary in the JSON array add the info to each table cell
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PlanetCell", for: indexPath)
        
        // Use optional binding to access the JSON dictionary if it exists
        if let jsonObj = jsonArray{
            
            // For the current tableCell row get the corresponding planet's dictionary of info
            let dictionaryRow = jsonObj[indexPath.row] as [String:Any]
            
            // Get the name and overview for the current planet
            let name = dictionaryRow["name"] as? String
            let distance = dictionaryRow["distance"] as? Int
            
            let formatter = NumberFormatter()
            formatter.groupingSeparator = ","
            formatter.numberStyle = .decimal
            
            let formattedDistance = formatter.string(from: NSNumber(integerLiteral: distance!))
            
            // Add the name and overview to the cell's textLabel
            cell.textLabel?.text = name!
            cell.detailTextLabel?.text = "\(formattedDistance!) km from the sun."
        }
        
        return cell
    }
    
    
    // Pass the current planet id to the next view when a cell is clicked
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ShowInfo" {
            // Get a reference to the next viewController class
            let nextVC = segue.destination as? PlanetInfoViewController
            
            // Get a reference to the cell that was clicked
            let thisCell = sender as? UITableViewCell
            // Set the planetId value of the next viewController
            let planetID = tableView.indexPath(for: thisCell!)!.row
            
            // Use optional binding to access the JSON dictionary if it exists
            if let jsonObj = jsonArray{
                nextVC?.jsonObj = jsonObj[planetID] as [String:Any]
            }
            
        }
    }
    
    
}
