//
//  ViewController.swift
//  URLRequestToRESTfulAPI
//
//  Created by seb on 2020-11-25.
//  Copyright © 2020 seb. All rights reserved.
//

import UIKit

class PlanetInfoViewController: UIViewController {
    
    // Create the UI outlets
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var descriptionTextView: UITextView!
    @IBOutlet weak var planetImageView: UIImageView!
    
    // Creat an int to identify the planet id that should be loaded
    var jsonObj: [String: Any]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Make variables to hold the current planets distance, and number of moons
        let name = jsonObj!["name"] as? String
        let day = jsonObj!["dayLength"] as? Double
        let year = jsonObj!["yearLength"] as? Double
        let volume = jsonObj!["volume"] as? Int
        let distance = jsonObj!["distance"] as? Int
        let moons = jsonObj!["moonCount"] as? Int
        
        // Setup number formatter for doubles
        let formatter = NumberFormatter()
        formatter.groupingSeparator = ","
        formatter.numberStyle = .decimal
        
        // Updste the labels and textView with the current planet's information
        if let name = name, let day = day, let year = year, let volume = volume, let distance = distance, let moons = moons {
            self.nameLabel.text = name
            if let formattedDistance = formatter.string(from: NSNumber(integerLiteral: distance)), let formattedVolume = formatter.string(from: NSNumber(integerLiteral: volume)){
                self.descriptionTextView.text = "Distance: \(formattedDistance) km from the sun\n\nNumber of moons: \(moons)\n\nLength of day: \(day) earth days\n\nLength of year: \(year) earth years\n\nVolume: \(formattedVolume) km³"
            }
        }
        // When the view loads call the function to request the image data
        loadPlanetImage()
    }
    
    
    func loadPlanetImage() {
        
        //Get the current planetId value
        if let planetID = jsonObj!["id"] as? Int {
            // Write a url using the currentID to request the image data
            if let imageRequestUrl: URL = URL(string: "https://lenczes.edumedia.ca/mad9137/pa_api/planet/read_img.php?id=\(planetID)") {
                // Create the request object and pass in your url
                let imageRequest: URLRequest = URLRequest(url: imageRequestUrl)
                // Create the URLSession object that will be used to make the requests
                let mySession: URLSession = URLSession.shared
                // Make the specific task from the session by passing in your image request, and the function that will be use to handle the image request
                let imageTask = mySession.dataTask(with: imageRequest, completionHandler: imageRequestTask )
                // Tell the image task to run
                imageTask.resume()
            }
        }
    }
    
    
    // Define a function that will handle the image request which will need to recieve the data send back, the response status, and an error object to handle any errors returned
    func imageRequestTask (_ serverData: Data?, serverResponse: URLResponse?, serverError: Error?) -> Void{
        
        // If the error object has been set then an error occured
        if let errorObject = serverError {
            // Send en empty string as the data, and the error to the callback function
            print("IMAGE LOADING ERROR: " + errorObject.localizedDescription)
        }else{
            // Else take the image data recieved from the server and process it
            // Because this callback is run on a secondary thread you must make any ui updates on the main thread by calling the dispatch_async method like so
            if let data = serverData {
                DispatchQueue.main.async {
                    // Set the ImageView's image by converting the data object into a UIImage
                    self.planetImageView.image = UIImage(data: data)
                }
            }
        }
    }
    
}

