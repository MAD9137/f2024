//
//  ViewController.swift
//  HttpAuthentication
//
//  Created by seb on 2020-11-25.
//  Copyright © 2020 seb. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var myLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func loadButton(_ sender: Any) {
        // Create a url set to the desired server address
        if let myUrl: URL = URL(string: "https://lenczes.edumedia.ca/mad9137/httpAuthentication/authRespond.php") {
            // Create the request object passing it the url object
            var myURLRequest: URLRequest = URLRequest(url: myUrl)
            
            // Create authentication credentials as a string converted to utf8 encoded data
            let authString = "seb:myPassword"
            if let utf8String = authString.data(using: String.Encoding.utf8) {
                // Convert the unicode data to base 64 bit encoded string
                let base64String = utf8String.base64EncodedString(options: .init(rawValue: 0))
                // Add the header key "Authorization" with the value of "Basic:" added before our converted data
                myURLRequest.addValue("Basic_" +  base64String, forHTTPHeaderField: "my-authentication")
            }
            
            // Create the URLSession object that will be used to make the requests
            let mySession: URLSession = URLSession.shared
            // Create a task from the session by passing in your request, and the callback handler
            let myTask = mySession.dataTask(with: myURLRequest, completionHandler: requestTask )
            // Tell the task to run
            myTask.resume()
        }
    }
    

    // Define a function that will handle the request, and if there are no errors display the data
    func requestTask (_ serverData: Data?, serverResponse: URLResponse?, serverError: Error?) -> Void{
        
        // Check if an error occured, and if not take the data recieved from the server and process it
        if let errorObject = serverError {
            // Send Error message if error occured
            print("ERROR: " + errorObject.localizedDescription)
        }else{
            // Stringify the response data
            if let data = serverData, let result = String(data: data, encoding: String.Encoding.utf8) {
                // Update the UI on the main thread with the new data
                DispatchQueue.main.async {
                    self.myLabel.text = "Server response text:\n" + result
                }
            }
            else {
                print("Server data object is nil, or failed to convert to string.")
                self.myLabel.text = "Server response error"
            }
        }
    }

}

