//
//  ViewController.swift
//  UserDefaultsWithImage
//
//  Created by Seb L on 2018-11-05.
//  Copyright © 2018 Seb L. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate{

    @IBOutlet weak var clearButton: UIButton!
    @IBOutlet weak var myTextField: UITextField!
    @IBOutlet weak var myImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        myTextField.delegate = self
        
        let userDefaults: UserDefaults = UserDefaults.standard
        
        let userName: String? = userDefaults.value(forKey: "myName") as? String
        let userImage: Data? = userDefaults.value(forKey: "myImage") as? Data
        
        if let name = userName, let img = userImage {
            myTextField.text = name
            myImageView.image = UIImage(data: img)
        } else {
            clearButton.isEnabled = false
        }
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        view.endEditing(true)
        return true
    }
    
    
    @IBAction func selectImageButtonAction(_ sender: Any) {
        myTextField.resignFirstResponder()
        let picker: UIImagePickerController = UIImagePickerController()
        picker.delegate = self
        picker.allowsEditing = false
        picker.sourceType = UIImagePickerController.SourceType.photoLibrary
        present(picker, animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
// Local variable inserted by Swift 4.2 migrator.
let info = convertFromUIImagePickerControllerInfoKeyDictionary(info)

        if let img = info[convertFromUIImagePickerControllerInfoKey(UIImagePickerController.InfoKey.originalImage)] as? UIImage {
            myImageView.image = img
        }
        
        picker.dismiss(animated: true, completion: nil)
    }
    
    
    
    
    @IBAction func saveButtonAction(_ sender: Any) {
        myTextField.resignFirstResponder()
        
        if let name = myTextField.text, let img = myImageView.image {
            let userDefaults: UserDefaults = UserDefaults.standard

            let imgData: Data = img.jpegData(compressionQuality: 40)!
            
            userDefaults.set(name, forKey: "myName")
            userDefaults.set(imgData, forKey: "myImage")
            
            clearButton.isEnabled = true
        }    }
    
    
    
    @IBAction func clearButtonAction(_ sender: Any) {
        myTextField.resignFirstResponder()
        
        let appDomain: String = Bundle.main.bundleIdentifier!
        UserDefaults.standard.removePersistentDomain(forName: appDomain)
        
        myTextField.text = ""
        myImageView.image = nil
        
        clearButton.isEnabled = false
    }
    
    
    
}


// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertFromUIImagePickerControllerInfoKeyDictionary(_ input: [UIImagePickerController.InfoKey: Any]) -> [String: Any] {
	return Dictionary(uniqueKeysWithValues: input.map {key, value in (key.rawValue, value)})
}

// Helper function inserted by Swift 4.2 migrator.
fileprivate func convertFromUIImagePickerControllerInfoKey(_ input: UIImagePickerController.InfoKey) -> String {
	return input.rawValue
}
