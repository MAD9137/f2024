<?php
	header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Headers: access");
	header("Access-Control-Allow-Credentials: true");
	
	ini_set('display_errors', 1);
	error_reporting(E_ALL);
	
	
	if( isset($_SERVER['HTTP_MY_AUTHENTICATION'])) {
		if( $_SERVER['HTTP_MY_AUTHENTICATION'] == "Basic_c2ViOm15UGFzc3dvcmQ=" ) {
	
			$partsDictionaryArray =  ["product" => "iPhone", "price" => "860"];
			header('Content-Type: application/json');
			echo json_encode($partsDictionaryArray);
		}
		else
		{
			echo "Error_Invalid_URL_Request: Not correct format.";
		}
	}
	else
	{
		echo "Error_Invalid_URL_Request: Missing request header.";
	}
	
?>