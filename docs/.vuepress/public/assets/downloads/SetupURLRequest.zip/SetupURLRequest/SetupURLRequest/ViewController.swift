//
//  ViewController.swift
//  SetupURLRequest
//
//  Created by seb on 2020-11-21.
//  Copyright © 2020 seb. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func loadDataButton(_ sender: Any) {
        
        // Write a url to the request data
        if let myUrl: URL = URL(string: "http://localhost:8888/MAD9137/SetupURLRequest/respond.php") {
            // Create the request object and pass in your url
            let myURLRequest: URLRequest = URLRequest(url: myUrl)
            // Create the URLSession object that will be used to make the requests
            let mySession: URLSession = URLSession.shared
            // Make the task from the session by passing in your request, and the callback handler
            let myTask = mySession.dataTask(with: myURLRequest, completionHandler: requestTask )
            // Tell the task to run
            myTask.resume()
        }
    }
    
    // Define a function that will handle the request, and if there are no errors display the data
    func requestTask (_ serverData: Data?, serverResponse: URLResponse?, serverError: Error?) -> Void{
        
        // Check if an error occured, and if not take the data recieved from the server and process it
        if let error = serverError {
            // Send Error message if error occured
            print("ERROR: " + error.localizedDescription)
        }else{
            // Stringify the response data
            if let data = serverData, let result = String(data: data, encoding: String.Encoding.utf8) {
                // Update the UI on the main thread with the new data
                DispatchQueue.main.async {
                    self.myLabel.text = "Got text: " + result
                }
            }
        }
    }
}

