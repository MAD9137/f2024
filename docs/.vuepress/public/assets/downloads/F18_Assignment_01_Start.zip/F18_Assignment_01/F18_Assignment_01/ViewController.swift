//
//  ViewController.swift
//  F18_Assignment_01
//
//  Created by Seb L on 2018-09-18.
//  Copyright © 2018 Seb L. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textViewOutlet: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        textViewOutlet.text = "TextView text has been updated."
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

