//
//  Event.swift
//  F18_Assignment_01
//
//  Created by Seb L on 2018-09-18.
//  Copyright © 2018 Seb L. All rights reserved.
//

import Foundation
