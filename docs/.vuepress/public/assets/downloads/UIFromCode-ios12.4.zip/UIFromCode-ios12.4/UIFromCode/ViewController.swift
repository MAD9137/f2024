//
//  ViewController.swift
//  UIFromCode
//
//  Created by Seb L on 2018-11-02.
//  Copyright © 2018 Seb L. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    // Declare some UI objects we want to create
    @IBOutlet var newTextView : UITextView!
    @IBOutlet var newTextField : UITextField!
    @IBOutlet var newImageView : UIImageView!
    @IBOutlet var newButton : UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // Create an Image
        makeImage()
        
        // Create a TextField
        makeTextField()
        
        // Create a TextView
        makeTextView()
        
        // Create a Button
        makeButton()
        
    }
    
    
    ///////////////////////
    // makeImage function
    func makeImage() {
        // Define the new imageView size and positioning with a rect
        let imageFrame = CGRect(x: 35, y: 35, width: 300, height: 223)
        
        // Create imageView object (size is automatically calculated from the image)
        newImageView = UIImageView(image: UIImage(named: "ACLogo"))
        
        // Add imageView to the main view
        self.view.addSubview(newImageView)
        
        // Set a new size if the original size is not desired
        newImageView.frame = imageFrame
    }
    
    
    //////////////////////////
    // makeTextField function
    func makeTextField() {
        // Define the new txtField size and positioning with a rect
        let txtFieldFrame = CGRect(x: 25, y: 280, width: 330, height: 40)
        
        // Create txtField object
        newTextField = UITextField(frame: txtFieldFrame)
        
        // Add txtField to the main view
        self.view.addSubview(newTextField)
        
        // Setup TextField placeholder-text, and style
        newTextField.placeholder = "This is placeholder text."
        
        // Setup TextField font
        newTextField.font = UIFont(name: newTextField.font!.fontName, size: 14)
        
        // Setup TextField text and background colors
        newTextField.backgroundColor = UIColor(red: 0.5, green: 0.8, blue: 0.5, alpha: 1.0)
        newTextField.textColor = UIColor.black
        
        // Setup TextField border style
        newTextField.layer.cornerRadius = 18
        newTextField.layer.borderWidth = 3
        newTextField.layer.borderColor = UIColor.lightGray.cgColor
        
        // Setup TextField padding
        newTextField.layer.sublayerTransform = CATransform3DMakeTranslation(10, 0, 0)
        
        // Setup TextField's security mode (normal or password)
        newTextField.isSecureTextEntry = false
    }
    
    
    /////////////////////////
    // makeTextView function
    func makeTextView() {
        // Define the new TextView size and positioning with a rect
        let textViewFrame = CGRect(x: 20, y: 340, width: 340, height: 160)
        
        // Create TextView object
        newTextView = UITextView(frame: textViewFrame)
        
        // Add TextView to the main view
        self.view.addSubview(newTextView)
        
        // Setup TextView text, and style
        newTextView.text = "This is some text."
        newTextView.textColor = UIColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        newTextView.backgroundColor = UIColor.darkGray
    }
    
    
    ///////////////////////
    // makeButton function
    func makeButton() {
        // Define the new Button size and positioning with a rect
        let buttonFrame = CGRect(x: 90, y: 535, width: 200, height: 50)
        
        // Create Button object
        newButton = UIButton(frame: buttonFrame)
        
        // Add TextView to the main view
        self.view.addSubview(newButton)
        
        // Setup Button text and style
        newButton.setTitle("Press Me", for: .normal)
        newButton.setTitleColor(UIColor.cyan, for: .highlighted)
        newButton.backgroundColor = UIColor.gray
    }
    
}

