//
//  ViewController.swift
//  ImageCameraPicker
//
//  Created by seb on 2020-11-10.
//  Copyright © 2020 seb. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate {

    @IBOutlet weak var myImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func chooseImageButton(_ sender: Any) {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.photoLibrary) {
            let picker: UIImagePickerController = UIImagePickerController() // Create an imagePicker object.
            picker.sourceType = UIImagePickerController.SourceType.photoLibrary // Set it's image source to photo library.
            picker.delegate = self // Set it's delegate to be this viewController class.
            picker.allowsEditing = false // Dont allow the user to edit the images in the picker.
            present(picker, animated: true, completion: nil) // Show the picker.
        }
        else {
            print("Photo library access is not available!") // Do something if the photo library is not allowed.
        }
    }
    
    @IBAction func takePhotoButton(_ sender: Any) {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.camera) {
            let picker: UIImagePickerController = UIImagePickerController() // Create an imagePicker object.
            picker.sourceType = UIImagePickerController.SourceType.camera // Set it's image source to the camera.
            picker.delegate = self // Set it's delegate to be this viewController class.
            picker.allowsEditing = false // Dont allow the user to edit the images in the picker.
            present(picker, animated: true, completion: nil) // Show the picker.
        }
        else {
            print("Camera is not available!") // Do something if the camera is not accessible.
        }
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil) // Hide the imagePicker if the user chooses to cancel.
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let img = info[UIImagePickerController.InfoKey.originalImage] as? UIImage { // Use optonal binding to get a reference to the image.
            myImageView.image = img // Do something with the selected image.
            picker.dismiss(animated: true, completion: nil) // Hide the imagePicker when done.
        }
    }
}

