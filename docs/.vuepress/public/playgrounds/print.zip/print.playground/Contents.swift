import UIKit

var greeting = "Hello, playgrounds"
print(greeting)
